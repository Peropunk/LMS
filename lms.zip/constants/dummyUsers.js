// Dummy users for authentication
export const dummyUsers = {
  admin: { email: "admin@ailms.com", password: "admin123" },
  teacher: { email: "teacher@ailms.com", password: "teach123" },
  student: { email: "student@ailms.com", password: "stud123" },
}; 