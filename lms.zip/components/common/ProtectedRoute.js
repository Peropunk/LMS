// ProtectedRoute Component (placeholder)
export default function ProtectedRoute({ children }) {
  // Add authentication logic here
  return children;
} 