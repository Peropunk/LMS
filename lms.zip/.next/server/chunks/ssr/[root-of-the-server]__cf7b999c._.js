module.exports = {

"[project]/components/common/Sidebar.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>Sidebar
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/link.js [ssr] (ecmascript)");
;
;
const linksByRole = {
    student: [
        {
            href: "/dashboard/student",
            label: "Dashboard Home"
        },
        {
            href: "/dashboard/student/classes",
            label: "Classes"
        },
        {
            href: "/dashboard/student/attendance",
            label: "Attendance"
        },
        {
            href: "/dashboard/student/quizzes",
            label: "Quizzes"
        },
        {
            href: "/dashboard/student/wallet",
            label: "Wallet"
        },
        {
            href: "/dashboard/student/store",
            label: "Store"
        },
        {
            href: "/dashboard/student/announcements",
            label: "Announcements"
        },
        {
            href: "/dashboard/student/parent-view",
            label: "Parent View"
        }
    ],
    teacher: [
        {
            href: "/dashboard/teacher",
            label: "Dashboard Home"
        },
        {
            href: "/dashboard/teacher/attendance",
            label: "Attendance"
        },
        {
            href: "/dashboard/teacher/syllabus",
            label: "Syllabus"
        },
        {
            href: "/dashboard/teacher/quizzes",
            label: "Quizzes"
        },
        {
            href: "/dashboard/teacher/performance",
            label: "Performance"
        },
        {
            href: "/dashboard/teacher/leave",
            label: "Leave"
        },
        {
            href: "/dashboard/teacher/salary",
            label: "Salary"
        }
    ],
    admin: [
        {
            href: "/dashboard/admin",
            label: "Dashboard Home"
        },
        {
            href: "/dashboard/admin/students",
            label: "Students"
        },
        {
            href: "/dashboard/admin/teachers",
            label: "Teachers"
        },
        {
            href: "/dashboard/admin/subjects",
            label: "Subjects"
        },
        {
            href: "/dashboard/admin/classes",
            label: "Classes"
        },
        {
            href: "/dashboard/admin/timetable",
            label: "Timetable"
        },
        {
            href: "/dashboard/admin/fees",
            label: "Fees"
        },
        {
            href: "/dashboard/admin/overview",
            label: "Overview"
        },
        {
            href: "/dashboard/admin/announcements",
            label: "Announcements"
        },
        {
            href: "/dashboard/admin/leaves",
            label: "Leaves"
        }
    ]
};
function Sidebar({ role = "student" }) {
    const links = linksByRole[role] || [];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("aside", {
        className: "w-64 h-full bg-gray-200 p-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("nav", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("ul", {
                className: "space-y-2",
                children: links.map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("li", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: link.href,
                            className: "block px-3 py-2 rounded hover:bg-gray-300 text-gray-800 font-medium",
                            children: link.label
                        }, void 0, false, {
                            fileName: "[project]/components/common/Sidebar.js",
                            lineNumber: 46,
                            columnNumber: 15
                        }, this)
                    }, link.href, false, {
                        fileName: "[project]/components/common/Sidebar.js",
                        lineNumber: 44,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/common/Sidebar.js",
                lineNumber: 42,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Sidebar.js",
            lineNumber: 41,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/common/Sidebar.js",
        lineNumber: 40,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/common/Navbar.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// Navbar Component
__turbopack_context__.s({
    "default": ()=>Navbar
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
;
function Navbar() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("nav", {
        className: "w-full h-16 bg-blue-600 flex items-center px-4 text-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
            className: "font-bold text-lg",
            children: "AI LMS"
        }, void 0, false, {
            fileName: "[project]/components/common/Navbar.js",
            lineNumber: 5,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/common/Navbar.js",
        lineNumber: 4,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/layout/TeacherLayout.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>TeacherLayout
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$Sidebar$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/Sidebar.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$Navbar$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/Navbar.js [ssr] (ecmascript)");
;
;
;
function TeacherLayout({ children, onLogout }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "flex min-h-screen bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$Sidebar$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                role: "teacher"
            }, void 0, false, {
                fileName: "[project]/components/layout/TeacherLayout.js",
                lineNumber: 7,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "flex-1 flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$Navbar$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        onLogout: onLogout
                    }, void 0, false, {
                        fileName: "[project]/components/layout/TeacherLayout.js",
                        lineNumber: 9,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("main", {
                        className: "flex-1 p-4",
                        children: children
                    }, void 0, false, {
                        fileName: "[project]/components/layout/TeacherLayout.js",
                        lineNumber: 10,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/layout/TeacherLayout.js",
                lineNumber: 8,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/layout/TeacherLayout.js",
        lineNumber: 6,
        columnNumber: 5
    }, this);
}
}),
"[project]/pages/dashboard/teacher/index.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>TeacherDashboard
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/link.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$TeacherLayout$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/TeacherLayout.js [ssr] (ecmascript)");
;
;
;
const teacherLinks = [
    {
        href: "/dashboard/teacher/attendance",
        label: "Attendance"
    },
    {
        href: "/dashboard/teacher/syllabus",
        label: "Syllabus"
    },
    {
        href: "/dashboard/teacher/quizzes",
        label: "Quizzes"
    },
    {
        href: "/dashboard/teacher/performance",
        label: "Performance"
    },
    {
        href: "/dashboard/teacher/leave",
        label: "Leave"
    },
    {
        href: "/dashboard/teacher/salary",
        label: "Salary"
    }
];
function TeacherDashboard() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$TeacherLayout$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-bold mb-6",
                children: "Teacher Dashboard"
            }, void 0, false, {
                fileName: "[project]/pages/dashboard/teacher/index.js",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("ul", {
                className: "space-y-3",
                children: teacherLinks.map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("li", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: link.href,
                            className: "block px-4 py-2 bg-green-100 rounded hover:bg-green-200 text-green-800 font-medium",
                            children: link.label
                        }, void 0, false, {
                            fileName: "[project]/pages/dashboard/teacher/index.js",
                            lineNumber: 20,
                            columnNumber: 13
                        }, this)
                    }, link.href, false, {
                        fileName: "[project]/pages/dashboard/teacher/index.js",
                        lineNumber: 19,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/pages/dashboard/teacher/index.js",
                lineNumber: 17,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/pages/dashboard/teacher/index.js",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__cf7b999c._.js.map