globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/[root-of-the-server]__838c21ac._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_82a36480.js",
      "static/chunks/node_modules_next_dist_compiled_ca41998d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_492fcef6._.js",
      "static/chunks/node_modules_next_dist_client_becf32a6._.js",
      "static/chunks/node_modules_next_dist_a3e9a08f._.js",
      "static/chunks/node_modules_next_router_47d9bb1c.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_a80c7711._.js",
      "static/chunks/pages_index_5771e187._.js",
      "static/chunks/pages_index_afa638e2._.js"
    ],
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_82a36480.js",
      "static/chunks/node_modules_next_dist_compiled_ca41998d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_492fcef6._.js",
      "static/chunks/node_modules_next_dist_client_becf32a6._.js",
      "static/chunks/node_modules_next_dist_a3e9a08f._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_a80c7711._.js",
      "static/chunks/[root-of-the-server]__f0fb4001._.js",
      "static/chunks/styles_globals_79636149.css",
      "static/chunks/pages__app_5771e187._.js",
      "static/chunks/pages__app_5e6c54f0._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];