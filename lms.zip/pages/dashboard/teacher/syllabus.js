export default function TeacherSyllabus() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Teacher Syllabus</h1>
      <p>TODO: Integrate with backend to fetch syllabus data.</p>
    </div>
  );
} 