export default function TeacherLeave() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Teacher Leave</h1>
      <p>TODO: Integrate with backend to fetch leave data.</p>
    </div>
  );
} 