export default function TeacherPerformance() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Teacher Performance</h1>
      <p>TODO: Integrate with backend to fetch performance data.</p>
    </div>
  );
} 