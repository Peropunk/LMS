export default function TeacherQuizzes() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Teacher Quizzes</h1>
      <p>TODO: Integrate with backend to fetch quizzes data.</p>
    </div>
  );
} 