export default function AdminLeaves() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Leaves</h1>
      <p>TODO: Integrate with backend to fetch leaves data.</p>
    </div>
  );
} 