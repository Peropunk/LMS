export default function AdminSubjects() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Subjects</h1>
      <p>TODO: Integrate with backend to fetch subjects data.</p>
    </div>
  );
} 