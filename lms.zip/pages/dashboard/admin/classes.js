export default function AdminClasses() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Classes</h1>
      <p>TODO: Integrate with backend to fetch classes data.</p>
    </div>
  );
} 