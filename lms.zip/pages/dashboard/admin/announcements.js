export default function AdminAnnouncements() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Announcements</h1>
      <p>TODO: Integrate with backend to fetch announcements data.</p>
    </div>
  );
} 