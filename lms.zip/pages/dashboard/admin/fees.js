export default function AdminFees() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Fees</h1>
      <p>TODO: Integrate with backend to fetch fees data.</p>
    </div>
  );
} 