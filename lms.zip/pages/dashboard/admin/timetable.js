export default function AdminTimetable() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Timetable</h1>
      <p>TODO: Integrate with backend to fetch timetable data.</p>
    </div>
  );
} 