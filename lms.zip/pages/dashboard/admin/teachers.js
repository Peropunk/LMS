export default function AdminTeachers() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Teachers</h1>
      <p>TODO: Integrate with backend to fetch teachers data.</p>
    </div>
  );
} 