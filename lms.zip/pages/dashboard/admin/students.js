export default function AdminStudents() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Students</h1>
      <p>TODO: Integrate with backend to fetch students data.</p>
    </div>
  );
} 