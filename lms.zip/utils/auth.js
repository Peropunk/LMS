import { dummyUsers } from "../constants/dummyUsers";

export function loginUser(role, email, password) {
  const user = dummyUsers[role];
  return user && user.email === email && user.password === password;
} 